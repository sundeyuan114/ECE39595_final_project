package game;
public class ChangedDisplayedType{
    public ChangedDisplayedType(String _name, Creature owner){
        System.out.println(""+owner+"changed displayed type");
    }
}