package game;
public class Structure extends Displayable{
    public boolean checkMove(int x, int y){
    }
}