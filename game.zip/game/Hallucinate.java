package game;
public class Hallucinate extends ItemAction{
    public Hallucinate(Item owner){
        super(owner);
        System.out.println(""+owner+"constructing hallucinate");
    }
}