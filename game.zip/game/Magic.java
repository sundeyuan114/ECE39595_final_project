package game;
public class Magic extends Displayable{

}