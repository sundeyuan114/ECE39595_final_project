package game;
public class Creature extends Displayable{
    public Creature(){
        System.out.println("Constructing creature");
    }

    @Override
    public void setHp(int h){
        System.out.println("Setting creature Hp to "+h);
    }

    @Override
    public void setHpMove(int hpm){
        System.out.println("Setting creature Hp moves to "+hpm);
    }

    public void setDeathAction(CreatureAction da){
        System.out.println("Setting death action to " + da);
    }

    public void setHitAction(CreatureAction ha){
        System.out.println("Setting hit action"+ha);
    }

    //public Char getrepr(){
    //}
}