package game;
public class Item extends Displayable{
    private String name;
    private ItemAction iAction;

    public void SetItemAction (ItemAction a){
        iAction = a;
    }

    public ItemAction getItemAction (){
        return iAction;
    }

    public void setOwner(Creature owner){
        System.out.println("Setting owner to "+ owner);
    }
    public void setName(String _name){
        name = _name;
    }

    public String getName() {
        return name;
    }

    public Char getrepr(){
        if (name.equals("Sword")){
            return new Char(')');
        }
        else if (name.equals("+10 Sword")){
            return new Char(')'); // change to regex later.
        }
        else if (name.equals("+10 Armor")){
            return new Char(']');
        }
        else if (name.equals("Armor")){
            return new Char(']');
        }
        else if (name.equals("Scroll")){
            return new Char('?');
        }
        else
        {
            System.out.println("item debug"+name);
            return new Char ('!');
        }
    }

}