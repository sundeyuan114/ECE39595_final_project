package game;
public class Action{
    public void setMessage(String msg){
        System.out.println("Setting action message "+msg);
    }

    public void setIntValue(int v){
        System.out.println("Setting int value "+v);
    }

    public void setCharValue(char c){
        System.out.println("Setting char value "+ c);
    }
}